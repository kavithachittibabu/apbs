var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');
var users = require('./routes/users');
var tellers = require('./routes/tellers');
var banks = require('./routes/banks');
var branches = require('./routes/branches');
var appointments = require('./routes/appointments');
var logins = require('./routes/logins');
var deposits = require('./routes/deposits');
var withdrawals = require('./routes/withdrawals');
var dialogs = require('./routes/dialogs');
var models=require('./models');
var error_handlers=require('./error_handlers');
var Sequelize=require('sequelize');
var socket=require('socket.io');
var socket_helper=require('./helpers/socket_helper');
var app = express();

//added by Kavitha - 17Dec
var chatapp = require('./routes/chat');

/*
function1(function2,callback1);
function2(function3,callback2);
function3(input-params); */


//bootstraping models
models(app);

//set socket.io object to app
var io=socket();
app.io=io;

//set business logic in sockets using app's socket object
socket_helper.socket_helper(app);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use('/static',express.static(path.join(__dirname, 'public')));

//register models in request
app.use(function(req,resp,next){
	req.db=app.db;
	req.models=app.db.models;
	next();
});

//register application specific routes
app.use('/', routes);
app.use('/api/v1/customers', users);
app.use('/api/v1/staffs', tellers);
app.use('/api/v1/banks', banks);
app.use('/api/v1/branches', branches);
app.use('/api/v1/appointments', appointments);
app.use('/api/v1/login', logins);
app.use('/api/v1/deposits', deposits);
app.use('/api/v1/withdrawals', withdrawals);
app.use('/api/v1/dialogs', dialogs);

//added by Kavitha - 17Dec
app.use('/apbs', chatapp);

// error handlers
error_handlers(app);

module.exports = app;
