function access_env_variable(key,value){
	var vcap_services=null;
	
	if(process.env['VCAP_SERVICES']){
		try{
			vcap_services=JSON.parse(process.env['VCAP_SERVICES']);
		}
		catch(err){
			console.log(err);
		}
	}
	
	if(key && vcap_services && vcap_services[key]){
		return vcap_services[key][0]['credentials'][value];
	}
	else{
		return process.env[value];
	}
};

var settings={
	database_prod:{
		username:access_env_variable('cleardb','username'),
		password:access_env_variable('cleardb','password'),
		schema:access_env_variable('cleardb','name'),
		options:{
			dialect:access_env_variable(null,'apbs_dialect'),
			host:access_env_variable('cleardb','hostname'),
			port:access_env_variable('cleardb','port'),
			pool:{
				min:0,
				max:5,
				idle:30000
			}
		}
	},
	database_dev:{
		username:access_env_variable(null,'apbs_db_username'),
		password:access_env_variable(null,'apbs_db_password'),
		schema:access_env_variable(null,'apbs_db_schema'),
		options:{
			dialect:access_env_variable(null,'apbs_dialect'),
			host:access_env_variable(null,'apbs_db_host'),
			port:access_env_variable(null,'apbs_db_port'),
			pool:{
				min:0,
				max:5,
				idle:30000
			}
		}
	}
};

module.exports=settings;
