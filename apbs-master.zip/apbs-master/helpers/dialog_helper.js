'use strict';

var watson=require('watson-developer-cloud');
var bluemix=require('../bluemix');
var extend=require('util')._extend;

//added by Kavitha - 17Dec
var appointmentController=require('../routes/controllers/appointment_controller');


var nlcCredentials = extend({
	version: 'v1',
	url : 'https://gateway.watsonplatform.net/natural-language-classifier/api',
  "username": "b86bd622-0ccd-40d2-badf-c0195ee61971",
    "password": "RJ3hQ38j6Dvl",
  }, bluemix.getServiceCreds('natural_language_classifier')); // VCAP_SERVICES

var dialogCredentials =  extend({
	url: 'https://gateway.watsonplatform.net/dialog/api',
    "username": "50ae3ed7-b065-4a7b-b0dc-1cde71612be9",
    "password": "l1aWnLmWfjUx",
	version: 'v1'
}, bluemix.getServiceCreds('dialog')); // VCAP_SERVICES

var nlClassifier = watson.natural_language_classifier(nlcCredentials);
var dialog  = watson.dialog(dialogCredentials);
var nlcClass;
var nlcConfidence;

//This method makes NLC call and calls dialog service if required
module.exports.callNLC = function(helperParams, callback) {

	console.log("IN NLC METHOD - INPUT TEXT   "+helperParams.inputText);

	var nlcParams = {
		classifier: "A3DA1Dx15-nlc-299",
		text: helperParams.inputText
	};
	
	nlClassifier.classify(nlcParams, function(err, nlcResults) {
		if (err){
			console.log("NLC error"+JSON.stringify(err));
		}
		else{
			nlcClass = nlcResults.classes[0].class_name;
			nlcConfidence = (nlcResults.classes[0].confidence);
		
			console.log("NLC Class name ==="+nlcClass+" and NLC confidence =="+nlcConfidence);

			if(nlcConfidence >.90){
				//call dialog service now
				console.log("CALL DIALOG WITH CLASSIFIED INPUT");

				var dialparams = {
					dialog_id: helperParams.dialog_id, 
					conversation_id: helperParams.conversation_id,
					client_id: helperParams.client_id,
					input: nlcClass
				};

				dialog.conversation(dialparams , function(err, dialResults) {
					if (err)
						console.log("error in helper conversation   ....   "+JSON.stringify(err));
					else{
						console.log("insdie NLC ------- Dialog Conversation Results"+JSON.stringify(dialResults));
						console.log("%%%%%%%%%%%%%%%%  dialResults %%%%%%%%%%%"+dialResults.response);

						callback(null,dialResults.response);
					}
				});
			  }
		  else{
				console.log("RETURN THE DEFAULT STRING"+helperParams.resultString);

				callback(null,helperParams.resultString);
			}
		}
	});

	console.log("this is called");
  
    return {};
};

module.exports.callDB = function(dbParams,db, callback) {
	console.log("in call DB method");
	

//added by Kavitha - 17Dec
	appointmentController.appointment_post_controller(dbParams,db, function(err,dbResults){
		if(err){
			console.log("db call returned error while storing appointment booking === "+JSON.stringify(err));
			return callback(err);
		}
		else{
			console.log("appointment saved");
			callback(null,dbResults);

		}
	});    //added by Kavitha - 17Dec - ends


};