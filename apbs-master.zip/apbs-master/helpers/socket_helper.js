var customNs=null;
var connected_clients=[];

function socket_helper(app){
	customNs=app.io.of('/apbs');
	
	customNs.on('connection',function(client_socket){
	
		//Store the client socket IP
		var clientIp=client_socket.request.connection.remoteAddress.split(':').splice(-1);
	
		//When client connects
		console.log('Client '+clientIp+': connected');
		
		//Store list of connected clients by socket id and client id
		client_socket.on('clientChannel',function(msg){
			var client={};
		
			client.client_id=client_socket.id;
			client.custom_id=msg;
			
			connected_clients.push(client);
		});
	
		//When client disconnects
		client_socket.on('disconnect',function(msg){
		
			for(var i=0;i<connected_clients.length;i++){
				var client=connected_clients[i];
				
				if(client.client_id===client_socket.id){
					connected_clients.splice(i,1);
					
					console.log('Client '+clientIp+': disconnected');
					
					break;
				}
			}
		});
	});
}

//Send pop up to client
function send_to_client(result,teller_id){

	console.log('sending result to client');
	
	//iterate through the list of connected clients and send the result to the client that matches the teller_id
	for(var i=0;i<connected_clients.length;i++){
		var client=connected_clients[i];
		
		if(client.custom_id===teller_id){
			customNs.connected[client.client_id].emit('serverChannel',JSON.stringify(result));
			break;
		}
	}
};

module.exports={
	socket_helper:socket_helper,
	send_to_client:send_to_client
};

