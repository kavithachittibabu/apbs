var Chance=require('chance');
var chance=new Chance();

//Set staff for appointment based on availability
var setStaffForAppointment=function(db,params){

	return db.models.staff.findAll({
		include:db.models.appointments
	}).then(function(staffs){
	
		if(staffs && staffs.length>0){
			for(var i=0;i<staffs.length;i++){
				if(staffs[i].appointments && staffs[i].appointments.length>0){
					continue;
				}
				else{
					 return staffs[i];
				}
			};
		}
		
		return null;
	});
};

//Set customer for an appointment based on passed in customer_id
var setCustomerForAppointment=function(db,params){
	return db.models.customer.findOne({
		where:{
			customer_id:params['customer_id']
		}
	});
};

//Create an appointment
var setAppointment=function(db,params){
	params.appointment_id=chance.ssn({dashes:false});
	
	return db.models.appointments.create({
		appointment_id:params.appointment_id,
		appt_purpose:params.purpose,
		appt_start_time:params.appt_start_time,
		appt_end_time:params.appt_end_time,
	})

};

module.exports={
	setStaffForAppointment:setStaffForAppointment,
	setCustomerForAppointment:setCustomerForAppointment,
	setAppointment:setAppointment
}
