var moment=require('moment');

//Sets start date and end date for appointment based on current time + bank timings
var getStartAndEndDate=function(time,start_time,end_time){

	var current_time=new moment();
	var bank_start_time=start_time || new moment().hours(9).minutes(0).seconds(0);
	var bank_end_time=end_time || new moment().hours(17).minutes(0).seconds(0);
	var bank_lunch_start_time=new moment().hours(12).minutes(30).seconds(0);
	var bank_lunch_end_time=new moment().hours(13).minutes(30).seconds(0);

	var result={};

	if(time==='today'){
		if(current_time<=bank_start_time){
			result.start_time=bank_start_time;
			result.end_time=new moment(bank_start_time).add(1,'hours');
		}
		
		else if(current_time>=bank_start_time && current_time<=bank_end_time 
			&& bank_end_time.diff(current_time,'hours')>=1){
			
			if(current_time<=bank_lunch_start_time && bank_lunch_start_time.diff(current_time,'hours')>=1){
				result.start_time=current_time;
				result.end_time=new moment(current_time).add(1,'hours');				
			}
			
			else if((current_time>=bank_lunch_start_time && current_time<=bank_lunch_end_time)
				|| (current_time<=bank_lunch_start_time && bank_lunch_start_time.diff(current_time,'hours')<1))
			{
				result.start_time=bank_lunch_end_time;
				result.end_time=new moment(bank_lunch_end_time).add(1,'hours')
			}
			
		}
		else{
			if(current_time.day()==5){
				result.start_time=new moment(bank_start_time).days(1);
				result.end_time=new moment(bank_start_time).days(1).add(1,'hours');	
			}
			else{
				result.start_time=new moment(bank_start_time).add(1,'days');
				result.end_time=new moment(bank_start_time).add(1,'days').add(1,'hours');	
			}
		}
	}
	else{
		if(current_time.day()==5){
			result.start_time=new moment(bank_start_time).days(1);
			result.end_time=new moment(bank_start_time).days(1).add(1,'hours');
		}
		else{
			result.start_time=new moment(bank_start_time).add(1,'days');
			result.end_time=new moment(bank_start_time).add(1,'days').add(1,'hours');
		}
	}
	
	return result;

};

module.exports={
	getStartAndEndDate:getStartAndEndDate,
};
