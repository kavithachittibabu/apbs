var express = require('express');
var controller=require('./controllers/appointment_controller');

var router = express.Router();

/* GET list of appointments*/
router.get('/', controller.appointment_list_controller);

/* POST appointment*/
router.post('/', function(req,resp,next){
	controller.appointment_post_controller(req.body,req.db,function(err,result){
		if(err){
			console.log(err);
			
			resp.status(err.status || 404);
			
			return resp.json({
				error:err.message
			});
		}
		
		return resp.json(result);
	});
});

/* GET single appointment*/
router.get('/:appointment_id', controller.appointment_get_controller);

module.exports = router;
