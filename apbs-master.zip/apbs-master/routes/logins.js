var express = require('express');
var controller=require('./controllers/login_controller');

var router = express.Router();

/* POST login customer*/
router.post('/', controller.login_post_controller);

/* POST load customer details when the customer taps his/her NFC mobile against a teller kiosk */
router.post('/nfc_authenticate', controller.login_nfc_auth_controller);

module.exports = router;
