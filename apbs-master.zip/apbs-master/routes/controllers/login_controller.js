var Promise=require('bluebird');
var socket_helper=require('../../helpers/socket_helper');
var bcrypt=require('bcrypt-nodejs');

//Login a user
var login_post_controller=function(req,resp,next){

	var result={};
	
	var params={
		account_number:req.body.account_number,
		password:req.body.password
	}
	
	req.models.customer.findOne({
		where:{
			account_number:params.account_number		
		},
		include:[req.models.login]
	}).then(function(customer){
	
		//compare the user entered password with the hashed password
		if(customer && bcrypt.compareSync(params.password,customer.login.password)){
			result={
				status:"success"
			};
		}
		else{
			resp.status(401);
		
			result={
				status:"fail"
			}
		}
		return resp.json(result);
	});
};

//Load customer and pop up details in teller app
var login_nfc_auth_controller=function(req,resp,next){

	var result={};
	
	var params={
		account_number:req.body.account_number,
		teller_id:req.body.teller_id
	}
	
	req.models.customer.findOne({
		where:{
			account_number:params.account_number		
		}
	}).then(function(customer){
	
		if(customer){
			
			result.customer_id=customer.customer_id;
			
			//call the socket helper to send the customer details to the teller app where the customer tapped his/her mobile
			socket_helper.send_to_client(result,params.teller_id);
		}
		else{
			resp.status(404);
		
			result={
				error:"No customer found"
			}
		}
		return resp.json(result);
	});
};

module.exports={
	login_post_controller:login_post_controller,
	login_nfc_auth_controller:login_nfc_auth_controller
}
