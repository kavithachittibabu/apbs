var Promise=require('bluebird');

//Retrieve list of staffs
var staff_list_controller=function(req,resp,next){

	var result={};
	
	req.models.staff.findAll({}).then(function(staffs){
	
		if(staffs.length==0){
			
			result={
				error:'No staffs found'
			};
			resp.status(404);
		}
		else{
			result={
				staffs:staffs
			};
		}
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Retrieve a single staff
var staff_get_controller=function(req,resp,next){

	var result={};
	
	return req.models.staff.create({
		where:{
			staff_id:req.params.staff_id
		}	
	}).then(function(staff){
		
		if(staff){
			result={
				staff:staff.get({
					plain:true
				})
			};	
		}
		else{
			resp.status(404);
			result={
				error:'No staff found'
			}
		}
	
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Create a single staff
var staff_post_controller=function(req,resp,next){

	var result={};
	
	var staff_promise=req.models.staff.create({
		staff_id:req.body.staff_id,
		staff_name:req.body.staff_name,
		age:req.body.age,
		gender:req.body.gender,
		role:req.body.role,
		home_address:req.body.address
	});
	
	var bank_promise=req.models.bank.findOne({
		where:{
			bank_name:'trustus'
		}
	});
	
	var branch_promise=req.models.branch.findOne({});
	
	return Promise.join(staff_promise,bank_promise,branch_promise,function(staff,bank,branch){
	
		if(staff && bank && branch){
		
			var staff_bank_promise=staff.setBank(bank);
			var staff_branch_promise=staff_bank_promise.then(function(staff){
				return staff.setBranch(branch);
			});
			
			return Promise.join(staff_branch_promise,function(staff){
				result={
					staff:staff.get({
						plain:true
					})
				}
				return resp.json(result);
			});
		}
	}).catch(function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

module.exports={
	staff_list_controller:staff_list_controller,
	staff_get_controller:staff_get_controller,
	staff_post_controller:staff_post_controller
}
