var date_helper=require('../../helpers/date_helper');
var appointment_helper=require('../../helpers/appointment_helper');
var Promise=require('bluebird');
var moment=require('moment');

//Retrieve list of appointments
var appointment_list_controller=function(req,resp,next){
	
	var result={};
	
	req.models.appointments.findAll({
		include:[req.models.customer,req.models.staff]
	}).then(function(appointments){
	
		if(appointments.length==0){
		
			result={
				error:'No appointments found'
			};
		
			resp.status(404);
		}
		else{
		
			result={
				appointments:[]
			};
		
			appointments.forEach(function(appointment){
				result.appointments.push({
					appointment_id:appointment.appointment_id,
					appointment_purpose:appointment.appt_purpose,
					appointment_start_time:appointment.appt_start_time.toLocaleString(),
					appointment_end_time:appointment.appt_end_time.toLocaleString(),
					appointment_date:moment(appointment.appt_start_time.getTime()).format('DD/MM/YYYY'),
					slot:moment(appointment.appt_start_time.getTime()).format('HH:mm A')+" - "+moment(appointment.appt_end_time.getTime()).format('HH:mm A'),
					customer:{
						customer_id:appointment.customer.customer_id,
						customer_name:appointment.customer.customer_name,
						age:appointment.customer.age,
						gender:appointment.customer.gender
					},
					staff:{
						staff_id:appointment.staff.staff_id,
						staff_name:appointment.staff.staff_name,
						age:appointment.staff.age,
						gender:appointment.staff.gender,
						role:appointment.staff.role
					}
				});
			});
		}
		
		return resp.json(result);
	},function(err){
	
		console.log(err);
	
		result={
			error:'Error occured while processing request'
		}
	
		resp.status(500);
		
		return resp.json(result);	
	});
};

//Retrieve single appointment
var appointment_get_controller=function(req,resp,next){
	
	var result={};
	
	req.models.appointments.find({
		where:{
			appointment_id:req.params.appointment_id
		},
		include:[req.models.customer,req.models.staff]
	}).then(function(appointment){
		if(appointment){
			result={
				appointment_id:appointment.appointment_id,
				appointment_purpose:appointment.appt_purpose,
				appointment_start_time:appointment.appt_start_time.toLocaleString(),
				appointment_end_time:appointment.appt_end_time.toLocaleString(),
				appointment_date:moment(appointment.appt_start_time.getTime()).format('DD/MM/YYYY'),
				slot:moment(appointment.appt_start_time.getTime()).format('HH:mm A')+" - "+moment(appointment.appt_end_time.getTime()).format('HH:mm A'),
				customer:{
					customer_id:appointment.customer.customer_id,
					customer_name:appointment.customer.customer_name,
					age:appointment.customer.age,
					gender:appointment.customer.gender
				},
				staff:{
					staff_id:appointment.staff.staff_id,
					staff_name:appointment.staff.staff_name,
					age:appointment.staff.age,
					gender:appointment.staff.gender,
					role:appointment.staff.role
				}
			};
		}
		else{
			result={
				error:'No appointments found'
			};
		
			resp.status(404);
		}
	
		return resp.json(result);
	},function(err){
	
		console.log(err);
	
		result={
			error:'Error occured while processing request'
		}
	
		resp.status(500);
		
		return resp.json(result);
	});
};

//Create a single appointment
var appointment_post_controller=function(req_params,db,callback){
	
	var req_body=req_params;
	var params={};
	var customer=null;
	var appointment=null;
	var result={};
	
	for(item in req_body){
		if(item==='time'){
			var time=date_helper.getStartAndEndDate(req_body[item]);
			params.appt_start_time=time.start_time;
			params.appt_end_time=time.end_time;
		}
		else{
			params[item]=req_body[item]
		}
	}
	
	var staff_promise=appointment_helper.setStaffForAppointment(db,params);
	var customer_promise=appointment_helper.setCustomerForAppointment(db,params);
	var appointment_promise=appointment_helper.setAppointment(db,params);
	
	return Promise.join(staff_promise,customer_promise,appointment_promise,function(staff,customer,appointment){
	
		if(!staff){
			var err=new Error("No staff available for this time");
			err.status=404;
			
			return callback(err);
		}

		var appointment_staff_promise=appointment.setStaff(staff);
		var appointment_customer_promise=appointment_staff_promise.then(function(appointment){
			return appointment.setCustomer(customer);
		});
		
		return Promise.join(appointment_customer_promise,function(appointment){

			result={
				appointment:{
					appointment_id:appointment.appointment_id,
					appointment_purpose:appointment.appt_purpose,
					appointment_start_time:appointment.appt_start_time.toLocaleString(),
					appointment_end_time:appointment.appt_end_time.toLocaleString(),
					appointment_date:moment(appointment.appt_start_time.getTime()).format('DD/MM/YYYY'),
					slot:moment(appointment.appt_start_time.getTime()).format('HH:mm A')+" - "+moment(appointment.appt_end_time.getTime()).format('HH:mm A'),
					customer:{
						customer_id:customer.customer_id,
						customer_name:customer.customer_name,
						age:customer.age,
						gender:customer.gender
					},
					staff:{
						staff_id:staff.staff_id,
						staff_name:staff.staff_name,
						age:staff.age,
						gender:staff.gender,
						role:staff.role
					}
				}
			};
			return callback(null,result);
		});
	}).catch(function(err){
		console.log(err);
		
		err.status=500;
		
		return callback(err);
	});
};

module.exports={
	appointment_list_controller:appointment_list_controller,
	appointment_get_controller:appointment_get_controller,
	appointment_post_controller:appointment_post_controller
}
