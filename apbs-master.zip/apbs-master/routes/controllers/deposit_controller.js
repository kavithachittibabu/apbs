var Promise=require('bluebird');
var Chance=require('chance');
var chance=new Chance();
var moment=require('moment');

//Return all deposits
var deposit_list_controller=function(req,resp,next){
	var result={};
	
	return req.models.deposit.findAll({
		include:[req.models.customer]
	}).then(function(deposits){
		if(deposits && deposits.length>0){
		
			result.deposits=[];
		
			deposits.forEach(function(deposit){
				result.deposits.push({
					deposit_id:deposit.deposit_id,
					date:moment(deposit.date.getTime()).format('DD/MM/YYYY'),
					account_number:deposit.account_number,					
					credit_card:deposit.credit_card?deposit.credit_card:'N/A',
					purpose:deposit.purpose,
					amount:deposit.amount,
					deposit_type:deposit.deposit_type,
					pan:deposit.pan?deposit.pan:'N/A',
					bank:deposit.bank?deposit.bank:'N/A',
					branch:deposit.branch?deposit.branch:'N/A',
					city:deposit.city?deposit.city:'N/A',
					cheque_no:deposit.cheque_no?deposit.cheque_no:'N/A',
					customer_id:deposit.customer?deposit.customer.customer_id:null
				});
			});
		}
		else{
		
			resp.status(404);
		
			result={
				error:'No deposits found'
			}
		}
		
		return resp.json(result);
		
	},function(err){
		console.log(err);
		
		resp.status(500);
	
		result={
			error:'Error occured while processing request'
		}
		
		return resp.json(result);
		
	});
	
};

//Return single deposit
var deposit_get_controller=function(req,resp,next){
	var result={};
	
	return req.models.deposit.findOne({
		where:{
			deposit_id:req.params.deposit_id
		},
		include:[req.models.customer]
	}).then(function(deposit){
		if(deposit){
			result={
				deposit_id:deposit.deposit_id,
				date:moment(deposit.date.getTime()).format('DD/MM/YYYY'),
				account_number:deposit.account_number,
				credit_card:deposit.credit_card?deposit.credit_card:'N/A',
				purpose:deposit.purpose,
				amount:deposit.amount,
				deposit_type:deposit.deposit_type,
				pan:deposit.pan?deposit.pan:'N/A',
				bank:deposit.bank?deposit.bank:'N/A',
				branch:deposit.branch?deposit.branch:'N/A',
				city:deposit.city?deposit.city:'N/A',
				cheque_no:deposit.cheque_no?deposit.cheque_no:'N/A',
				customer_id:deposit.customer?deposit.customer.customer_id:null
			};
		}
		else{
		
			resp.status(404);
		
			result={
				error:'No deposit found'
			}
		}
		
		return resp.json(result);
		
	},function(err){
		console.log(err);
		
		resp.status(500);
	
		result={
			error:'Error occured while processing request'
		}
		
		return resp.json(result);
		
	});
	
};

//Create a new deposit
var deposit_post_controller=function(req,resp,next){

	var result={};
	
	var params={
		deposit_id:chance.ssn({
			dashes:false
		}),
		date:moment(req.body.date,'DD/MM/YYYY').toDate(),
		account_number:req.body.account_number,
		credit_card:req.body.credit_card?req.body.credit_card:null,
		purpose:req.body.purpose,
		amount:req.body.amount,
		deposit_type:req.body.deposit_type?req.body.deposit_type:'cash',
		pan:req.body.pan?req.body.pan:null,
		bank:req.body.bank?req.body.bank:null,
		branch:req.body.branch?req.body.branch:null,
		city:req.body.city?req.body.city:null,
		cheque_no:req.body.cheque_no?req.body.cheque_no:0		
	};
	
	var deposit_promise=req.models.deposit.create(params);
	var customer_promise=req.models.customer.findOne({
		where:{
			$or:[
				{customer_id:req.body.customer_id},
				{account_number:req.body.customer_account_number}
			]
		}
	});
	
	return Promise.join(deposit_promise,customer_promise,function(deposit,customer){
		if(deposit && customer){
			deposit.setCustomer(customer).then(function(d){
			
				result={
					deposit_id:deposit.deposit_id
				};
			
				return resp.json(result)
			});
		}
		else{
			throw new Error('Error occured while proessing the request');
		}	
	}).catch(function(err){
		console.log(err);
		
		resp.status(500);
		
		result={
			error:err.message
		};
		
		return resp.json(result);
		
	});
};

module.exports={
	deposit_post_controller:deposit_post_controller,
	deposit_get_controller:deposit_get_controller,
	deposit_list_controller:deposit_list_controller	
}
