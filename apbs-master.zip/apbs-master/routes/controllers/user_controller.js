var Promise=require('bluebird');
var Chance=require('chance');
var chance=new Chance();
var moment=require('moment');
var bcrypt=require('bcrypt-nodejs');

//Retrieve list of users
var user_list_controller=function(req,resp,next){

	req.models.customer.findAll({}).then(function(users){
	
		if(users.length==0){
			
			result={
				error:'No users found'
			};
			resp.status(404);
		}
		else{
			result={
				users:users
			};
		}
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Retrieve a single user
var user_get_controller=function(req,resp,next){

	var result={};
	
	req.models.customer.findOne({
		where:{
			customer_id:req.params.customer_id
		}
	}).then(function(user){
		if(user){
			result.customer=user.get({
				plain:true
			});
		}

		else{
			resp.status(404);
			result.error='No user found';
		}
	
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Create a new user
var user_post_controller=function(req,resp,next){

	var result={};
	
	var account_number=chance.integer();
	
	account_number=account_number<0?-(account_number):account_number;
	
	var user_promise=req.models.customer.create({
		customer_id:req.body.customer_id,
		customer_name:req.body.customer_name,
		age:req.body.age,
		gender:req.body.gender,
		account_number:account_number
	});
	
	var bank_promise=req.models.bank.findOne({
		where:{
			bank_name:'trustus'
		}
	});
	
	var login_promise=req.models.login.create({
		username:req.body.username,
		password:bcrypt.hashSync(req.body.password) //store the hash+salt password instead of the plain one
	});
	
	return Promise.join(user_promise,bank_promise,login_promise,function(customer,bank,login){
		if(customer && bank && login){
			return customer.addBank(bank).then(function(user){
				return customer.setLogin(login);
			}).then(function(user){
				result={
					customer:customer.get({
						plain:true
					})
				};

				return resp.json(result);
			});
		}
		else{
			throw new Error('Error occured while processing request');
		}
	}).catch(function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Retrieve appointments for a single customer
var user_appointment_controller=function(req,resp,next){
	
	var result={};
	
	req.models.customer.findOne({
		where:{
			customer_id:req.params.customer_id
		},
		include:[{
			model:req.models.appointments,
			include:[{
				model:req.models.staff
			}]
		}]
	}).then(function(customer){
	
		if(!customer){
		
			result={
				error:'No customer found'
			};
		
			resp.status(404);
		}
		else if(!customer.appointments || customer.appointments.length==0){
			
			result={
				error:'No appointments found'
			}
			
			resp.status(404);
		}
		else{
		
			result={
				customer:{
					customer_id:customer.customer_id,
					customer_name:customer.customer_name,
					account_number:customer.account_number,
					age:customer.age,
					gender:customer.gender,
					appointments:[]
				}
			};
		
			customer.appointments.forEach(function(appointment){
				result.customer.appointments.push({
					appointment_id:appointment.appointment_id,
					appointment_purpose:appointment.appt_purpose,
					appointment_date:moment(appointment.appt_start_time.getTime()).format('DD/MM/YYYY'),
					slot:moment(appointment.appt_start_time.getTime()).format('HH:mm A')+" - "+moment(appointment.appt_end_time.getTime()).format('HH:mm A'),
					staff:{
						staff_id:appointment.staff.staff_id,
						staff_name:appointment.staff.staff_name,
						age:appointment.staff.age,
						gender:appointment.staff.gender,
						role:appointment.staff.role
					}
				});
			});
		}
		
		return resp.json(result);
	},function(err){
	
		console.log(err);
	
		result={
			error:'Error occured while processing request'
		}
	
		resp.status(500);
		
		return resp.json(result);	
	});
};

//Retrieve deposits for a single customer
var user_deposit_controller=function(req,resp,next){
	var result={};
	
	req.models.customer.findOne({
		where:{
			customer_id:req.params.customer_id
		},
		include:[{
			model:req.models.deposit,
		}]
	}).then(function(customer){
	
		if(!customer){
		
			result={
				error:'No customer found'
			};
		
			resp.status(404);
		}
		else if(!customer.deposits || customer.deposits.length==0){
			
			result={
				error:'No deposits found'
			}
			
			resp.status(404);
		}
		else{
		
			result={
				customer:{
					customer_id:customer.customer_id,
					customer_name:customer.customer_name,
					account_number:customer.account_number,
					age:customer.age,
					gender:customer.gender,
					deposits:[]
				}
			};
		
			customer.deposits.forEach(function(deposit){
				result.customer.deposits.push({
					deposit_id:deposit.deposit_id,
					date:moment(deposit.date.getTime()).format('DD/MM/YYYY'),
					account_number:deposit.account_number,					
					credit_card:deposit.credit_card?deposit.credit_card:'N/A',
					purpose:deposit.purpose,
					amount:deposit.amount,
					deposit_type:deposit.deposit_type,
					pan:deposit.pan?deposit.pan:'N/A',
					bank:deposit.bank?deposit.bank:'N/A',
					branch:deposit.branch?deposit.branch:'N/A',
					city:deposit.city?deposit.city:'N/A',
					cheque_no:deposit.cheque_no?deposit.cheque_no:'N/A'
				});
			});
		}
		
		return resp.json(result);
	},function(err){
	
		console.log(err);
	
		result={
			error:'Error occured while processing request'
		}
	
		resp.status(500);
		
		return resp.json(result);	
	});
};

//Retrieve withdrawals for a single customer
var user_withdrawal_controller=function(req,resp,next){
	var result={};
	
	req.models.customer.findOne({
		where:{
			customer_id:req.params.customer_id
		},
		include:[{
			model:req.models.withdrawal,
		}]
	}).then(function(customer){
	
		if(!customer){
		
			result={
				error:'No customer found'
			};
		
			resp.status(404);
		}
		else if(!customer.withdrawals || customer.withdrawals.length==0){
			
			result={
				error:'No withdrawals found'
			}
			
			resp.status(404);
		}
		else{
		
			result={
				customer:{
					customer_id:customer.customer_id,
					customer_name:customer.customer_name,
					account_number:customer.account_number,
					age:customer.age,
					gender:customer.gender,
					withdrawals:[]
				}
			};
		
			customer.withdrawals.forEach(function(withdrawal){
				result.customer.withdrawals.push({
					withdrawal_id:withdrawal.withdrawal_id,
					from_account_number:withdrawal.from_account_number,
					amount:withdrawal.amount,
					pan:withdrawal.pan?withdrawal.pan:'N/A'
				});
			});
		}
		
		return resp.json(result);
	},function(err){
	
		console.log(err);
	
		result={
			error:'Error occured while processing request'
		}
	
		resp.status(500);
		
		return resp.json(result);	
	});
};

module.exports={
	user_list_controller:user_list_controller,
	user_get_controller:user_get_controller,
	user_post_controller:user_post_controller,
	user_appointment_controller:user_appointment_controller,
	user_deposit_controller:user_deposit_controller,
	user_withdrawal_controller:user_withdrawal_controller
}
