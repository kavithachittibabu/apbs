var Promise=require('bluebird');
var Chance=require('chance');
var chance=new Chance();
var moment=require('moment');

//Return all withdrawals
var withdrawal_list_controller=function(req,resp,next){
	var result={};
	
	return req.models.withdrawal.findAll({
		include:[req.models.customer]
	}).then(function(withdrawals){
		if(withdrawals && withdrawals.length>0){
		
			result.withdrawals=[];
		
			withdrawals.forEach(function(withdrawal){
				result.withdrawals.push({
					withdrawal_id:withdrawal.withdrawal_id,
					from_account_number:withdrawal.from_account_number,
					amount:withdrawal.amount,
					pan:withdrawal.pan?withdrawal.pan:'N/A',
					customer_id:withdrawal.customer?withdrawal.customer.customer_id:null
				});
			});
		}
		else{
		
			resp.status(404);
		
			result={
				error:'No withdrawals found'
			}
		}
		
		return resp.json(result);
		
	},function(err){
		console.log(err);
		
		resp.status(500);
	
		result={
			error:'Error occured while processing request'
		}
		
		return resp.json(result);
		
	});
	
};

//Return single withdrawal
var withdrawal_get_controller=function(req,resp,next){
	var result={};
	
	return req.models.withdrawal.findOne({
		where:{
			withdrawal_id:req.params.withdrawal_id
		},
		include:[req.models.customer]
	}).then(function(withdrawal){
		if(withdrawal){
			result={
				withdrawal_id:withdrawal.withdrawal_id,
				from_account_number:withdrawal.from_account_number,
				amount:withdrawal.amount,
				pan:withdrawal.pan?withdrawal.pan:'N/A',
				customer_id:withdrawal.customer?withdrawal.customer.customer_id:null
			};
		}
		else{
		
			resp.status(404);
		
			result={
				error:'No withdrawal found'
			}
		}
		
		return resp.json(result);
		
	},function(err){
		console.log(err);
		
		resp.status(500);
	
		result={
			error:'Error occured while processing request'
		}
		
		return resp.json(result);
		
	});
	
};

//Create a new withdrawal
var withdrawal_post_controller=function(req,resp,next){

	var result={};
	
	var params={
		withdrawal_id:chance.ssn({
			dashes:false
		}),
		date:moment(req.body.date,'DD/MM/YYYY').toDate(),
		from_account_number:req.body.from_account_number,
		amount:req.body.amount,
		pan:req.body.pan?req.body.pan:null
	};
	
	var withdrawal_promise=req.models.withdrawal.create(params);
	var customer_promise=req.models.customer.findOne({
		customer_id:req.body.customer_id
	});
	
	return Promise.join(withdrawal_promise,customer_promise,function(withdrawal,customer){
		if(withdrawal && customer){
			withdrawal.setCustomer(customer).then(function(w){
			
				result={
					withdrawal_id:withdrawal.withdrawal_id
				};
			
				return resp.json(result)
			});
		}
		else{
			throw new Error('Error occured while proessing the request');
		}	
	}).catch(function(err){
		console.log(err);
		
		resp.status(500);
		
		result={
			error:err.message
		};
		
		return resp.json(result);
		
	});
};

module.exports={
	withdrawal_post_controller:withdrawal_post_controller,
	withdrawal_get_controller:withdrawal_get_controller,
	withdrawal_list_controller:withdrawal_list_controller	
}
