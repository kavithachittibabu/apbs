var Promise=require('bluebird');
var Chance=require('chance');
var chance=new Chance();

//Retrieve list of banks
var bank_list_controller=function(req,resp,next){
	
	var result={};
	
	req.models.bank.findAll({}).then(function(banks){
	
		if(banks.length==0){
			
			result={
				error:'No banks found'
			};
			resp.status(404);
		}
		else{
			result={
				banks:banks
			};
		}
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Retrieve a single bank
var bank_get_controller=function(req,resp,next){
	
	req.models.bank.findOne({
		where:{
			$or:[
				{
					bank_name:req.params.bank_name_or_code
				},
				{
					bank_code:req.params.bank_name_or_code
				},
			]
		}
	}).then(function(bank){
		var result={};

		if(bank){
			result.bank=bank.get({
				plain:true
			});
		}

		else{
			resp.status(404);
			result.error='No bank found';
		}
	
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Create a new bank
var bank_post_controller=function(req,resp,next){

	var result={};
	
	req.models.bank.create({
		bank_name:req.body.bank_name,
		bank_code:chance.ssn({
			dashes:false
		})
	}).then(function(bank){
		if(bank){
			result={
				bank:bank.get({
					plain:true
				})
			};
			return resp.json(result);
		}	
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});	
};

module.exports={
	bank_list_controller:bank_list_controller,
	bank_get_controller:bank_get_controller,
	bank_post_controller:bank_post_controller
}
