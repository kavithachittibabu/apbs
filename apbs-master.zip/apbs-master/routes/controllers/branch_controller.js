var Promise=require('bluebird');
var Chance=require('chance');
var chance=new Chance();

//Retrieve list of branches
var branch_list_controller=function(req,resp,next){
	
	req.models.branch.findAll({}).then(function(branches){
	
		if(branches.length==0){
			
			result={
				error:'No branches found'
			};
			resp.status(404);
		}
		else{
			result={
				branches:branches
			};
		}
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Retrieve a single branch
var branch_get_controller=function(req,resp,next){
	
	var result={};
	
	req.models.branch.findOne({
		where:{
			branch_code:req.params.branch_code
		}
	}).then(function(branch){
		if(branch){
			result.customer=branch.get({
				plain:true
			});
		}

		else{
			resp.status(404);
			result.error='No branch found';
		}
	
		return resp.json(result);
	},function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

//Create a single branch
var branch_post_controller=function(req,resp,next){

	var result={};
	
	var branch_promise=req.models.branch.create({
		branch_name:req.body.branch_name,
		branch_code:chance.ssn({
			dashes:false
		}),
		location:req.body.location
	});
	
	var bank_promise=req.models.bank.findOne({
		where:{
			bank_name:'trustus'
		}
	});
	
	return Promise.join(branch_promise,bank_promise,function(branch,bank){
		if(branch && bank){
			
			var branch_promise=branch.setBank(bank);
			
			return Promise.join(branch_promise,function(branch){
				result={
					branch:branch.get({
						plain:true
					})
				}
				resp.json(result);
			});
		}
	}).catch(function(err){
		console.log(err);
		resp.status(500);
		return resp.json({
			error:err.message
		});
	});
};

module.exports={
	branch_list_controller:branch_list_controller,
	branch_get_controller:branch_get_controller,
	branch_post_controller:branch_post_controller
}
