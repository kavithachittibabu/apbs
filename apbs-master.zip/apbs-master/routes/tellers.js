var express = require('express');
var controller=require('./controllers/teller_controller');

var router = express.Router();

/* GET list of staffs */
router.get('/', controller.staff_list_controller);

/* POST staff*/
router.post('/', controller.staff_post_controller);

/* GET single staff*/
router.get('/:staff_id', controller.staff_get_controller);

module.exports = router;
