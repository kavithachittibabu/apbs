var express = require('express');
var controller=require('./controllers/withdrawal_controller');

var router = express.Router();

/* GET list of withdrawals*/
router.get('/', controller.withdrawal_list_controller);

/* POST withdrawal*/
router.post('/', controller.withdrawal_post_controller);

/* GET single withdrawal*/
router.get('/:withdrawal_id', controller.withdrawal_get_controller);

module.exports = router;
