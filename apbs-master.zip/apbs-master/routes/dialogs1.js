var express = require('express');
var dialoghelper=require('../helpers/dialog_helper');
var async=require('async');
var extend=require('util')._extend;
var fs=require('fs');
var path=require('path');
var bluemix=require('../bluemix');
var watson=require('watson-developer-cloud');

var router = express.Router();

// if bluemix credentials exists, then override local
var credentials =  extend({
	url: 'https://gateway.watsonplatform.net/dialog/api',
    "username": "8af54adf-b1a6-4a79-b972-c6258cdf7965",
    "password": "mOcGNJ7eyA35",
	version: 'v1'
}, bluemix.getServiceCreds('dialog')); // VCAP_SERVICES

// Create the service wrapper
var dialog = watson.dialog(credentials);
var dialog_id = process.env.DIALOG_ID || '<dialog-id>';

var client_id;

dialog_id="9369ccd6-18c9-49bb-b4bb-b7856a7351a6";

router.post('/conversation', function(req, res, next) {
	console.log("printing req body values ======================= "+JSON.stringify(req.body));

	var params = extend({ dialog_id: dialog_id }, req.body);
	var client_id;
	var conversation_id;
	var defaultFlag=false;
	var nlcFlag = false;
	var inputText = req.body.input;
	var resultString;
	var aptTime="";

	console.log("input text ================ "+req.body.input);
		
	dialog.conversation(params, function(err, results) {
		if (err)
			return next(err);
		else{
			console.log("Dialog Conversation Results"+JSON.stringify(results));
			
			client_id = results.client_id;
			conversation_id = results.conversation_id;
			
			console.log("Array value? ==== "+results.response[0]);
			
			resultString = results.response[0];
			resultString = results.response;
			
			// call getProfile of dialog
			var getProfileParams = {
				dialog_id: dialog_id,
				client_id: client_id
			};

			dialog.getProfile(getProfileParams, function(err, resultsProfile){
				if(err)
					console.log("error thrown in Dialog Getprofile"+err);
				else{
					console.log("RESULT PROFILE ******************"+JSON.stringify(resultsProfile));

					resultsProfile.name_values.forEach(function(par){
						if ( par.name != "" &&  par.name=="DefaultFlag"){
							console.log("------------------------Default Flag is set to ------------------"+  par.name + ':', par.value);

							defaultFlag=par.value;
						}
						else if(par.name !="" && par.name == "AppointmentTime"){
							aptTime = par.value;

							console.log("in else class and appointment time is "+aptTime);
						}
					});	
				}

				var helperParams = {
					dialog_id: dialog_id,
					client_id: client_id,
					conversation_id: conversation_id,
					inputText: inputText,
					resultString: resultString
				};

					async.waterfall([
						function(callback){
							if(defaultFlag){
								dialoghelper.callNLC(helperParams, function(errTxt,nlcResults){
									
									if(errTxt){
										console.log("error thrown in nlc method"+JSON.stringify(errTxt));
									}
									else{
										console.log("Results from nlc method "+nlcResults);

										resultString = nlcResults;
										callback(null, resultString);
									}
								});

							}
							else
								callback(null, resultString);									
						},
							function(retStr, callback){
								console.log("in teh db call method"+aptTime);

								// call db here...
								if(aptTime !=""){
									// call db here
									var dbParams = {												
										client_id: client_id,
										conversation_id: conversation_id,
										name: "Customer",
										"time": aptTime,
										"purpose": "Account Opening"
									};
								
									console.log("in teh db call method inside if"+aptTime);
									console.log("req.db ====== "+req.db);

									//added by Kavitha - 17Dec
									dialoghelper.callDB(dbParams,req.db, function(errDB,dbResults){
										if(errDB){
											console.log("Error while making db call -->  "+JSON.stringify(errDB));
											resultString = JSON.stringify(errDB);
											console.log("Result String ==== "+resultString);
											callback(null,resultString);
										}
										else{
											resultString = "[\"I have booked the appointment for you between "+ dbResults.slot+ "\" ]";

											console.log("confirmation string ===== "+resultString);

											callback(null, resultString);
										}
									});
									//added by Kavitha - 17Dec ends
									;

									console.log("to form the response with reference no"+aptTime);
									// call dialog update methond and update appointment reference time here.
								}
								else{
									console.log("call getProfile here");
									console.log("in second methond ==== "+retStr);

									callback(null, retStr)
								}
							}

						], function(error, resultFinal){
							if (error)
							{
								console.log("error in asynch block");
							}
							else{
								results["response"] = eval(resultString);
						
								console.log("conversation results"+ JSON.stringify(results));

								res.json({ dialog_id: dialog_id, conversation: results});

								// update profile - reset default Flag value
								console.log("CLIENT ID IS"+client_id);
		
								var restoreParams = {												
									dialog_id: dialog_id,												
									"client_id": client_id,
									"name_values":[
										{
											"name":"DefaultFlag",
											"value":"false"
										},
										{
											"name":"User_Name",
											"value":"Anjali"
										}
									]
								};

								dialog.updateProfile(restoreParams, function(updateErr, updateResults){
									if(updateErr)
										console.log("Error restoring thevalues"+JSON.stringify(updateErr));
									else
										console.log("Values restored in dialog"+JSON.stringify(updateResults));
								});
							}
						});

				}); // end of getProfile
			}	
	});	// end of dialog post

}); // end of app.post

router.post('/profile', function(req, res, next) {
  var params = extend({ dialog_id: dialog_id }, req.body);
  dialog.getProfile(params, function(err, results) {
    if (err)
      return next(err);
    else
      res.json(results);
  });
});

module.exports = router;
