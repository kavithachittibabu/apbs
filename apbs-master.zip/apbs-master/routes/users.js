var express = require('express');
var controller=require('./controllers/user_controller');

var router = express.Router();

/* GET list of customers*/
router.get('/', controller.user_list_controller);

/* POST customer*/
router.post('/', controller.user_post_controller);

/* GET single customer*/
router.get('/:customer_id', controller.user_get_controller);

/* GET appointments for single customer*/
router.get('/:customer_id/appointments', controller.user_appointment_controller);

/* GET deposits for single customer*/
router.get('/:customer_id/deposits', controller.user_deposit_controller);

/* GET withdrawals for single customer*/
router.get('/:customer_id/withdrawals', controller.user_withdrawal_controller);

module.exports = router;
