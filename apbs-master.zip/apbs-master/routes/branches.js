var express = require('express');
var controller=require('./controllers/branch_controller');

var router = express.Router();

/* GET list of branches */
router.get('/', controller.branch_list_controller);

/* POST branch*/
router.post('/', controller.branch_post_controller);

/* GET single branch*/
router.get('/:branch_code', controller.branch_get_controller);

module.exports = router;
