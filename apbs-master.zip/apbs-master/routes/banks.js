var express = require('express');
var controller=require('./controllers/bank_controller');

var router = express.Router();

/* GET list of banks */
router.get('/', controller.bank_list_controller);

/* POST bank*/
router.post('/', controller.bank_post_controller);

/* GET single bank*/
router.get('/:bank_name_or_code', controller.bank_get_controller);

module.exports = router;
