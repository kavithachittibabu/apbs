var express = require('express');
var controller=require('./controllers/deposit_controller');

var router = express.Router();

/* GET list of deposits*/
router.get('/', controller.deposit_list_controller);

/* POST deposit*/
router.post('/', controller.deposit_post_controller);

/* GET single deposit*/
router.get('/:deposit_id', controller.deposit_get_controller);

module.exports = router;
