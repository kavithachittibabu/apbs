module.exports=function(sequelize,DataTypes){
	console.log('--> About to define appointments model');
	
	sequelize.define('appointments',{
		appointment_id:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		},
		appt_purpose:{
			type:DataTypes.STRING,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		},
		appt_start_time:{
			type:DataTypes.DATE,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		},
		appt_end_time:{
			type:DataTypes.DATE,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		}		
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> appointments model defined');
}
