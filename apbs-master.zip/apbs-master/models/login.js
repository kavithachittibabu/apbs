module.exports=function(sequelize,DataTypes){
	console.log('--> About to define Login model');
	
	sequelize.define('login',{
		username:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		},
		password:{
			type:DataTypes.STRING,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		}
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> Login model defined');
}
