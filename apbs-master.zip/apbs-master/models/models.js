var User=require('./user');
var Teller=require('./teller');
var Bank=require('./bank');
var Branch=require('./branch');
var Appointment=require('./appointment');
var Login=require('./login');
var Deposit=require('./deposit');
var Withdrawal=require('./withdrawal');

var models=[User,Teller,Bank,Branch,Appointment,Login,Deposit,Withdrawal]

var establish_relations=function(db){
	var user=db.models.customer;
	var teller=db.models.staff;
	var bank=db.models.bank;
	var branch=db.models.branch;
	var appointment=db.models.appointments;
	var login=db.models.login;
	var deposit=db.models.deposit;
	var withdrawal=db.models.withdrawal;
	
	//User has can have account in many banks
	user.belongsToMany(bank,{through:'user_bank'});
	
	//Bank can have many users
	bank.belongsToMany(user,{through:'user_bank'});
	
	//User can have many appointments
	user.hasMany(appointment);
	
	//Appointment can belong to only one user
	appointment.belongsTo(user);
	
	//User can have many appointments
	teller.hasMany(appointment);
	
	//Appointment can belong to only one user
	appointment.belongsTo(teller)

	//Bank can have many staffs
	bank.hasMany(teller);
	
	//Staff can belong to only one bank
	teller.belongsTo(bank);
	
	//Bank can have many branches
	bank.hasMany(branch);
	
	//Branch can belong to only one brank
	branch.belongsTo(bank);
	
	//Branch can have many staffs
	branch.hasMany(teller);
	
	//Staff can belong to only one branch
	teller.belongsTo(branch);
	
	//user has only one login
	user.hasOne(login);
	
	//login belongs to only one user
	login.belongsTo(user);
	
	//user has many deposits
	user.hasMany(deposit);
	
	//deposit belongs to only one user	
	deposit.belongsTo(user);
	
	//user has many withdrawals	
	user.hasMany(withdrawal);
	
	//withdrawal belongs to only one user	
	withdrawal.belongsTo(user);
};


module.exports=function(sequelize,DataTypes){

	console.log('--> About to defined models');

	models.forEach(function(model){
		model(sequelize,DataTypes);
	});
	
	console.log('--> Models defined successfully');
	
	console.log('--> About to define relations');
	
	establish_relations(sequelize)
		
	console.log('--> Relations defined successfully');
	
	return sequelize;
};
