module.exports=function(sequelize,DataTypes){
	console.log('--> About to define branch_timings model');
	
	sequelize.define('branch_timings',{
		weekday_timings:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
		weekend_timings:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
		weekday_lunch_timings:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
		weekend_lunch_timings:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> branch_timings model defined');
}
