module.exports=function(sequelize,DataTypes){
	console.log('--> About to define withdrawal model');
	
	sequelize.define('withdrawal',{
		withdrawal_id:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		},
		from_account_number:{
			type:DataTypes.BIGINT,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		},
		amount:{
			type:DataTypes.DECIMAL(10,2),
			allowNull:false,
			validate:{
				notEmpty:true,
			}
		},
		pan:{
			type:DataTypes.STRING,
			allowNull:true,
			validate:{
				notEmpty:true
			}
		}
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> withdrawal model defined');
}
