module.exports=function(sequelize,DataTypes){
	console.log('--> About to define Bank model');
	
	sequelize.define('bank',{
		bank_name:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		},
		bank_code:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		}
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> Bank model defined');
}
