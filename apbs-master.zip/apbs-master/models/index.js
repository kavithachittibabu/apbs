var Sequelize=require('sequelize');
var settings=require('../settings');

var connection=null;

var create_connection=function(app,callback){

	if(connection){
		return callback(null,connection);
	}

	try{
	
		var sequelize=null;
		
		if(app.get('env')==='development'){
			//sequelize=new Sequelize(settings.database_dev.schema,settings.database_dev.username,settings.database_dev.password,settings.database_dev.options);
			sequelize=new Sequelize('mysql://bb040d667d43af:0a5ae472@us-cdbr-iron-east-03.cleardb.net:3306/ad_65be3d5b0de097d?reconnect=true');
		}
		else{
			//sequelize=new Sequelize(settings.database_prod.schema,settings.database_prod.username,settings.database_prod.password,settings.database_prod.options);
			//sequelize=new Sequelize(settings.database_prod.schema,settings.database_prod.username,settings.database_prod.password,settings.database_prod.options);
			sequelize=new Sequelize('mysql://bb040d667d43af:0a5ae472@us-cdbr-iron-east-03.cleardb.net:3306/ad_65be3d5b0de097d?reconnect=true');



		}
		
		return sequelize.authenticate().then(function(){
			console.log('--> Successfully connected to database');
		
			connection=sequelize;
		
			sequelize.import(__dirname+'/models');
		
			console.log('--> Syncing models with database');
		
			sequelize.sync().then(function(){
				console.log('--> Successfully synced');
		
				return callback(null,connection);
			},function(err){
				console.log(err);
			
				return callback(err);
			});		
		},function(err){
			console.log(err);
			
			return callback(err);
		});
	}
	catch(err){
		return callback(err);
	}

};

var load_models=function(app){

	console.log('--> About to establish connection');

	return create_connection(app,function(err,db){
		if(err){
			console.log(err);
			return;
		}
		
		app.db=db;
		
		return;
	});
};

module.exports=load_models;
