module.exports=function(sequelize,DataTypes){
	console.log('--> About to define branch_features model');
	
	sequelize.define('branch_features',{
		nfc:{
			type:DataTypes.BOOLEAN,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
		sara:{
			type:DataTypes.BOOLEAN,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		},
		weekends:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:false,
			validate:{
				notEmpty:true
			}
		}
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> branch_features model defined');
}
