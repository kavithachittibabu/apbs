module.exports=function(sequelize,DataTypes){
	console.log('--> About to define Branch model');
	
	sequelize.define('branch',{
		branch_name:{
			type:DataTypes.STRING,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		},
		branch_code:{
			type:DataTypes.STRING,
			allowNull:false,
			unique:true,
			validate:{
				notEmpty:true
			}
		},
		location:{
			type:DataTypes.TEXT,
			allowNull:false,
			validate:{
				notEmpty:true
			}
		}
	},{
		freezeTableName:true,
		underscored:true
	});
	
	console.log('--> Branch model defined');
}
