(function(){
	var apbsControllers=angular.module('apbsControllers',['apbsServices']);

	//Controller that helps in achieving the pop up functionality
	apbsControllers.controller('apbsHomeController',function($scope,$rootScope,$location,socket){
	
		//when receiving a message over the server channel
		socket.getSocket().on('serverChannel',function(msg){

			console.log('Message from server: '+msg);
		
			try{
				var result=JSON.parse(msg);
				
				if(result && result.customer_id){
					//when receiving customer id over the channel, redirect to customer dashboard
					$rootScope.$apply(function(){
						$location.path('/dashboard/'+result.customer_id);
					});
				}
			}catch(err){
				console.log(err);
			}
		});
	});
	
	//Controller that handles the dashboard for a customer
	apbsControllers.controller('apbsDashboardController',function($scope,$routeParams,apbsServices){
	
		//customer model
		$scope.customer=null;
		
		//sets the current view
		$scope.currentView='avatar';
		
		//call the apbs service to retrieve the customer details
		var result=apbsServices.getCustomerDetails($routeParams.customer_id);
		
		if(result.then && 'function'===typeof result.then){
			result.then(function(customer){
				$scope.customer=customer;
			});
		}
		else{
			$scope.customer=result;
		}
		
		//Helper method to validate the current view with the given view
		$scope.isCurrentView=function(view_name){
		
			return $scope.currentView===view_name;
		};
		
		//Load the appointment details from a service for the given customer id
		$scope.displayAppointments=function(){
		
			//call apbs service to retrieve the appointments for a customer
			var result=apbsServices.getAppointments($routeParams.customer_id);
		
			if(result.then && 'function'===typeof result.then){
				result.then(function(data){
					if(!data.error){
						$scope.customer.appointments=data.appointments;
					}
					else{
						$scope.customer.appointments=null;
					}
				});
			}
			else{
				$scope.customer.appointments=result.appointments;
			}
		
			//set the current view
			$scope.currentView='appointment';
		};
		
		//Load the deposit details from a service for the given customer id
		$scope.displayDeposits=function(){
		
			//call apbs service to retrieve the deposits for a customer
			var result=apbsServices.getDeposits($routeParams.customer_id);
		
			if(result.then && 'function'===typeof result.then){
				result.then(function(customer){
					$scope.customer.deposits=customer.deposits;
				});
			}
			else{
				$scope.customer.deposits=result.deposits;
			}
		
			//set the current view
			$scope.currentView='deposit';
		};
		
		//Load the withdrawal details from a service for the given customer id	
		$scope.displayWithdrawals=function(){
		
			//call apbs service to retrieve the withdrawals for a customer		
			var result=apbsServices.getWithdrawals($routeParams.customer_id);
		
			if(result.then && 'function'===typeof result.then){
				result.then(function(customer){
					$scope.customer.withdrawals=customer.withdrawals;
				});
			}
			else{
				$scope.customer.withdrawals=result.withdrawals;
			}
		
			//set the current view
			$scope.currentView='withdrawal';
		};
		
		//Remove customer details from the current model
		$scope.logout=function(){
			$scope.customer=null;
			
			//call apbs service to remove the customer details
			apbsServices.clearCustomerDetails();
			
			//redirect to home page
			$rootScope.$apply(function(){
				$location.path('/home');
			});
		};
		
		//helper to check if a model is empty
		$scope.isEmpty=function(item){
			if(item==undefined || item==null || item.length==0){
				return true;
			}
			
			return false;
		};
	});
	
	//Controller that creates the socket connection and register the teller id with socket server
	apbsControllers.controller('apbsTellerController',function($scope,socket){
		//Teller model
		$scope.teller={};
		
		//create socket
		$scope.tellerSetup=function(){
		
			//call socket service to create socket
			socket.createSocket();
			
			//Logging when successful connection to server is made
			socket.getSocket().on('connect',function(){
				console.log('connected to server');
			});
			
			//send the teller id to server so that the server can store it against this socket
			socket.getSocket().emit('clientChannel',$scope.teller.teller_id);
		};
		
	});
	
})();
