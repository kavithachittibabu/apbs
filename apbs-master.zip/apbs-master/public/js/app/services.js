(function(){
	var apbsServices=angular.module('apbsServices',[]);
	
	//private socket object
	var socket;
	
	//create socket factory
	apbsServices.factory('socket',function(){
	
		//method to create socket
		var createSocket=function(){
			socket=io(window.location.origin+'/apbs');
			return;
		};
		
		//get the current socket
		var getSocket=function(){
			return socket;
		};
	
		return {
			createSocket:createSocket,
			getSocket:getSocket
		};
	});
	
	//create apbsServices factory
	apbsServices.factory('apbsServices',function($http){
	
		//private customer model
		var customer={};
	
		//failure callback
		var failureCallback=function(resp){
			return {
				error:resp.statusText,
				status:resp.status
			};
		};
	
		//method to retrieve customer details
		var getCustomerDetails=function(customer_id){
		
			//return the cached version of customer to avoid unnecessary calls
			if(customer && customer.customer_id===customer_id){
				return customer;
			}
		
			//call apbs system to retrieve customer details
			return $http({
				method:'get',
				url:'/api/v1/customers/'+customer_id,
				responseType:'json'
			}).then(function(resp){
				//store the customer details onto the private customer model, so that it can be reused
				customer=resp.data.customer;
				
				return customer;
			},failureCallback);
		};
		
		//method to retrieve appointment details		
		var getAppointments=function(customer_id){
		
			//return the cached version of appointments to avoid unnecessary calls
			if(customer && customer.appointments){
				return customer;
			}
		
			//call apbs system to retrieve appointment details
			return $http({
				method:'get',
				url:'/api/v1/customers/'+customer_id+'/appointments',
				responseType:'json'
			}).then(function(resp){
				//store the appointment details onto the private customer model, so that it can be reused
				customer.appointments=resp.data.customer.appointments;
				
				return customer;
			},failureCallback);
		};
		
		//method to retrieve deposit details			
		var getDeposits=function(customer_id){
		
			if(customer && customer.deposits){
				return customer;
			}
		
			//call apbs system to retrieve deposits details
			return $http({
				method:'get',
				url:'/api/v1/customers/'+customer_id+'/deposits',
				responseType:'json'
			}).then(function(resp){
				//store the deposit details onto the private customer model, so that it can be reused
				customer.deposits=resp.data.customer.deposits;
	
				return customer;
			},failureCallback);
		};
		
		//method to retrieve withdrawal details			
		var getWithdrawals=function(customer_id){
		
			if(customer && customer.withdrawals){
				return customer;
			}
		
			//call apbs system to retrieve withdrawal details		
			return $http({
				method:'get',
				url:'/api/v1/customers/'+customer_id+'/withdrawals',
				responseType:'json'
			}).then(function(resp){
				//store the withdrawal details onto the private customer model, so that it can be reused			
				customer.withdrawals=resp.data.customer.withdrawals;
				
				return customer;
			},failureCallback);
		};
		
		//method to clear private customer model on logging out
		var clearCustomerDetails=function(){
			customer=null;
		}
		
		return {
			getCustomerDetails:getCustomerDetails,
			getAppointments:getAppointments,
			getDeposits:getDeposits,
			getWithdrawals:getWithdrawals,
			clearCustomerDetails:clearCustomerDetails
		};
	});
	
})();
