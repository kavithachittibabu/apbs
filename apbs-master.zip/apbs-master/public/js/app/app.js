(function(){
	var app=angular.module('apbsApp',['apbsControllers','ngRoute']);
	
	//Defining routes to be used of the client side app
	/*
	
	 / - Launches login screen
	 /home - Launches home screen
	 /dashboard/:customer_id - Launches the dashboard for the customer
	  
	*/
	app.config(function($routeProvider){
		$routeProvider.when('/',{
			templateUrl:'/static/partials/teller_setup.html',
			controller:'apbsTellerController'
		}).when('/home',{
			templateUrl:'/static/partials/home.html',
			controller:'apbsHomeController'
		}).when('/dashboard/:customer_id',{
			templateUrl:'/static/partials/dashboard.html',
			controller:'apbsDashboardController'
		}).otherwise({
			redirectTo:'/'
		});
	});
})();
